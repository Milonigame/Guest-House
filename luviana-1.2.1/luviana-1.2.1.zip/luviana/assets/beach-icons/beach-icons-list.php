<?php
return [
	"Beach Icons" => [
		"beach-icons icon-01",
		"beach-icons icon-02",
		"beach-icons icon-14",
		"beach-icons icon-15",
		"beach-icons icon-03",
		"beach-icons icon-16",
		"beach-icons icon-04",
		"beach-icons icon-05",
		"beach-icons icon-06",
		"beach-icons icon-07",
		"beach-icons icon-08",
		"beach-icons icon-10",
		"beach-icons icon-09",
		"beach-icons icon-11",
		"beach-icons icon-13",
		"beach-icons icon-12"
	]
];