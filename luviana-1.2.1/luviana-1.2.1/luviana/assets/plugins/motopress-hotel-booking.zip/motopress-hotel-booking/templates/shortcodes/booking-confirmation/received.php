<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<p>
    <?php _e('We are pleased to inform you that your reservation request has been received and confirmed.', 'motopress-hotel-booking'); ?>
</p>