<?php

namespace MPHB\iCal;

class ImportStatus {

	const FAILED	 = 0;
	const SUCCESS	 = 1;
	const SKIPPED	 = 2;

}
