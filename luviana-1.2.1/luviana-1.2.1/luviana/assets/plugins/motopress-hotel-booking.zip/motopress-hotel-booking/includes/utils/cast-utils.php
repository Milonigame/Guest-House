<?php

namespace MPHB\Utils;

class CastUtils {
	/**
	 * @param $value
	 *
	 * @return int
	 */
	public static function toInt( $value ) {
		return (int) $value;
	}
}